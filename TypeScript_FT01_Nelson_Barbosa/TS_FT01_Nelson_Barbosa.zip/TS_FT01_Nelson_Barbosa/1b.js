"use strict";
// B
/*
let firstNumber : number = 0
let secondNumber : number = 0
let thirdNumber : number = 0
let average : number = 0
let message : string = ""

firstNumber = Number (prompt ("Please insert the first number"))
secondNumber = Number (prompt ("Please insert the second number"))
thirdNumber = Number (prompt ("Please insert the third number"))

average = (firstNumber + secondNumber + thirdNumber) / 3

message = `The average is ${average}.`

alert(message)
*/ 
