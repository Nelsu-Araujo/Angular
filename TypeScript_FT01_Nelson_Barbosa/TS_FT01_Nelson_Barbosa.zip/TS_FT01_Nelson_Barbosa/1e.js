"use strict";
// E
/*
let base : number = 0
let height : number = 0
let area : number = 0
let message : string = ""

base = Number (prompt ("Please insert the base: "))
height = Number (prompt ("Please insert the height: "))

area = (base * height) / 2

message = `The area of the triangle is ${area}`

alert(message)
*/ 
