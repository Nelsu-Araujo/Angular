"use strict";
// C
/*
let firstNumber : number = 0
let secondNumber : number = 0
let division : number = 0
let message : string = ""

firstNumber = Number (prompt ("Please insert the first number"))
secondNumber = Number (prompt ("Please insert the second number"))

division = firstNumber / secondNumber

message = `The division between the two numbers is ${division}.`

alert(message)
*/ 
