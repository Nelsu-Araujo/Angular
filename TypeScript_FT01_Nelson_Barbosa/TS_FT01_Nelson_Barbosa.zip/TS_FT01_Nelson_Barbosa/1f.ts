// F

/*
let price : number = 0
let total : number = 0
let message : string = ""

price = Number (prompt ("Please insert the price without taxes:"))

total = (price * 1.25)

message = `The total price is ${total}€.`

alert(message)
*/