"use strict";
// D
/*
let firstNumber : number = 0
let predecessor : number = 0
let successor : number = 0
let message : string = ""

firstNumber = Number (prompt ("Please enter one number"))

predecessor = firstNumber - 1
successor = firstNumber + 1

message = `Predecessor: ${predecessor} ; Successor: ${successor}`

alert(message)
*/ 
