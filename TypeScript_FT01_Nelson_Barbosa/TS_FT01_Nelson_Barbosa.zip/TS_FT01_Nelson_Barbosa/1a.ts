// A

/*
let firstNumber : number = 0
let secondNumber : number = 0
let result : number = 0
let message : string = ""

firstNumber = Number (prompt ("Please insert the first number"))
secondNumber = Number (prompt ("Please insert the second number"))

result = firstNumber * secondNumber;

message = `The result of the two numbers is ${result}.`

alert(message)
*/